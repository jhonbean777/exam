import React, { useState, useEffect } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import axios from "axios";
import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Grid,
  TextField,
  Typography,
  styled,
} from "@mui/material";

const EmpCreate = () => {
  const initialValues = {
    name: "",
    email: "",
    phone: "",
  };

  const [existingEmails, setExistingEmails] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:8000/employee")
      .then((response) => {
        const emails = response.data.map((item) => item.email);
        setExistingEmails(emails);
      })
      .catch((error) => {
        console.error("Error loading existing emails:", error);
      });
  }, []);

  const navigate = useNavigate();

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .required("First Name is required")
      .matches(/(?=.*[',A-Z,a-z])/, "Name must contain a letter.")
      .min(2, "Too Short!")
      .max(25, "Too Long!"),
    lastName: Yup.string()
      .required("Last Name is required")
      .matches(/(?=.*[',A-Z,a-z])/, "Name must contain a letter.")
      .min(2, "Too Short!")
      .max(25, "Too Long!"),
    email: Yup.string()
      .email("Invalid email")
      .required("Email is required")
      .test("unique-email", "Email is already in use", function (value) {
        return !existingEmails.includes(value);
      }),
    age: Yup.string()
      .required("Age is required"),
    gender: Yup.string()
      .required("Gender is required"),
    education: Yup.string()
      .required("Education is required")
  });

  const handleSubmit = (values) => {
    axios
      .post("http://localhost:8000/employee", values)
      .then((response) => {
        alert("Saved Data Successfully..");
        navigate("/");
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  const StyledCard = styled(Card)(({ theme }) => ({
    padding: theme.spacing(4),
  }));

  return (
    <Container className="create-section">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            style={{ height: "100vh" }}
          >
            <Grid item xs={12} md={8} lg={6} xl={5}>
              <StyledCard>
                <CardContent>
                  <Typography variant="h4" gutterBottom>
                    Add New User
                  </Typography>
                  <Field
                    as={TextField}
                    fullWidth
                    name="firstName"
                    label="FirstName"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="firstName"
                    className="error"
                    component="div"

                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="lastName"
                    label="LastName"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="lastName"
                    className="error"
                    component="div"

                  />

                  <Field
                    as={TextField}
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="email"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="gender"
                    label="Gender"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="gender"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="age"
                    label="Age"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="age"
                    className="error"
                    component="div"

                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="education"
                    label="Education"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="education"
                    className="error"
                    component="div"

                  />
                  <Box mt={2}>
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      size="large"
                    >
                      Save
                    </Button>
                    <Button
                      component={RouterLink}
                      to="/"
                      variant="contained"
                      color="secondary"
                      size="large"
                      className="btn"
                      style={{ marginLeft: "8px" }}
                    >
                      Back
                    </Button>
                  </Box>
                </CardContent>
              </StyledCard>
            </Grid>
          </Grid>
        </Form>
      </Formik>
    </Container>
  );
};

export default EmpCreate;
