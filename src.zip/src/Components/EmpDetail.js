import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  styled,
} from "@mui/material";

const EmpDetail = () => {
  const { empid } = useParams();

  const [empdata, empdatachange] = useState({});

  useEffect(() => {
    fetch(`http://localhost:8000/employee/${empid}`)
      .then((res) => res.json())
      .then((resp) => {
        empdatachange(resp);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, [empid]);

  return (
    <Container className="outer">
      <Container className="detail-section">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>First Name</TableCell>
              <TableCell>Last Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Age</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>Education</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {empdata && (
              <TableRow>
                <TableCell>{empdata.id}</TableCell>
                <TableCell>{empdata.firstName}</TableCell>
                <TableCell>{empdata.lastName}</TableCell>
                <TableCell>{empdata.email}</TableCell>
                <TableCell>{empdata.age}</TableCell>
                <TableCell>{empdata.gender}</TableCell>
                <TableCell>{empdata.education}</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Container>
    </Container>
  );
};

export default EmpDetail;
