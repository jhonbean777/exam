// import React, { useEffect, useState } from "react";
// import { Formik, Form, Field, ErrorMessage } from "formik";
// import * as Yup from "yup";
// import { Link, useParams, useNavigate } from "react-router-dom";


// const EmpEdit = () => {
//   const { empid } = useParams();
//   const navigate = useNavigate();

//   // Define the initial form values
//   const initialValues = {
//     name: "",
//     email: "",
//     phone: "",
//     id: ""
//   };

//   // Validation schema using Yup
//   const validationSchema = Yup.object().shape({
//     name: Yup.string()
//       .required("Name is required")
//       .matches(/(?=.*[a-zA-Z])/, "Name must contain letters"),
//     email: Yup.string().email("Invalid email").required("Email is required"),
//     phone: Yup.string()
//       .matches(/^\+(?:[0-9] ?){6,14}[0-9]$/, "Invalid phone number")
//       .required("Phone number is required"),
//   });

//   const [submittedData, setSubmittedData] = useState(null);

//   const handleSubmit = (values) => {
//     fetch("http://localhost:7000/employee/" + empid, {
//       method: "PUT",
//       headers: { "content-type": "application/json" },
//       body: JSON.stringify(values)
//     }).then((res) => {
//       alert('Saved successfully.')
//       navigate('/');
//     }).catch((err) => {
//       console.log(err.message)
//     })
//   }

//   useEffect(() => {
//     // Fetch and populate the form data based on empid
//     fetch("http://localhost:7000/employee/" + empid)
//       .then((res) => res.json())
//       .then((resp) => {
//         initialValues.id = resp.id;
//         initialValues.name = resp.name;
//         initialValues.email = resp.email;
//         initialValues.phone = resp.phone;
//       })
//       .catch((err) => {
//         console.log(err.message);
//       });
//   }, [empid]);


//   return (
//     <div>
//       <Formik
//         initialValues={initialValues}
//         validationSchema={validationSchema}
//         onSubmit={handleSubmit}
//       >
//         <Form className="mb-2">
//           <section className="vh-100 form-section">
//             <div className="container py-5 h-90">
//               <div className="row d-flex justify-content-center align-items-center h-80">
//                 <div className="col-12 col-md-8 col-lg-6 col-xl-5">
//                   <div className="card shadow-2-strong  edit-section">
//                     <div className="card-body p-5 text-center">
//                       <h2 className="my-4 font-weight-bold .display-4">Edit user</h2>
//                       <div className="my-5">
//                         <Field
//                           className="form-control"
//                           type="text"
//                           id="id"
//                           name="id"
//                           placeholder='Id'
//                           disabled="disabled"
//                         />
//                       </div>
//                       <div className="my-5">
//                         <Field
//                           className="form-control"
//                           type="text"
//                           id="name"
//                           name="name"
//                           placeholder='Name'
//                         />
//                         <ErrorMessage
//                           className="error"
//                           name="name"
//                           component="div"
//                         />
//                       </div>
//                       <div className="my-5">
//                         <Field
//                           className="form-control "
//                           type="email"
//                           id="email"
//                           name="email"
//                           disabled="disabled"
//                           placeholder='Email'
//                         />
//                         <ErrorMessage
//                           className="error"
//                           name="email"
//                           component="div"
//                         />
//                       </div>
//                       <div className="my-5">
//                         <Field
//                           className="form-control"
//                           type="tel"
//                           id="phone"
//                           name="phone"
//                           placeholder='Phone No.'
//                         />
//                         <ErrorMessage
//                           className="error"
//                           name="phone"
//                           component="div"
//                         />
//                       </div>
//                       <div className="col-lg-12">
//                         <div className="form-group">
//                           <button className="btn btn-success" type="submit">Save</button>
//                           <Link to="/" className="btn btn-danger">Back</Link>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </section>
//         </Form>
//       </Formik>
//     </div>
//   );
// };

// export default EmpEdit;




import React, { useEffect, useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Grid,
  TextField,
  Typography,
  styled,
} from "@mui/material";

const EmpEdit = () => {
  const { empid } = useParams();
  const navigate = useNavigate();

  const initialValues = {
    name: "",
    email: "",
    phone: "",
    id: "",
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .required("Name is required")
      .matches(/(?=.*[a-zA-Z])/, "Name must contain letters"),
    email: Yup.string().email("Invalid email").required("Email is required"),
    phone: Yup.string()
      .matches(
        /^\+(?:[0-9] ?){6,14}[0-9]$/,
        "Invalid phone number"
      )
      .required("Phone number is required"),
  });

  const [submittedData, setSubmittedData] = useState(null);

  const handleSubmit = (values) => {
    axios
      .put(`http://localhost:7000/employee/${empid}`, values)
      .then((res) => {
        alert("Saved successfully.");
        navigate("/");
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  useEffect(() => {
    axios
      .get(`http://localhost:7000/employee/${empid}`)
      .then((res) => {
        const resp = res.data;
        initialValues.id = resp.id;
        initialValues.firstname = resp.firstname;
        initialValues.lasttname = resp.lastname;
        initialValues.email = resp.email;
        initialValues.gender = resp.gender;
        initialValues.age = resp.age;
        initialValues.education = resp.education;

      })
      .catch((err) => {
        console.log(err.message);
      });
  }, [empid]);

  const StyledCard = styled(Card)(({ theme }) => ({
    padding: theme.spacing(4),
  }));

  return (
    <Container className="edit-section">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            style={{ height: "100vh" }}
          >
            <Grid item xs={12} md={8} lg={6} xl={5}>
              <StyledCard>
                <CardContent>
                  <Typography variant="h4" gutterBottom>
                    Edit User
                  </Typography>
                  <Field
                    as={TextField}
                    fullWidth
                    name="id"
                    label="Id"
                    variant="outlined"
                    margin="normal"
                    disabled
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="firstname"
                    label="FirstName"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="firstname"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="lastname"
                    label="LastName"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="lastname"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="Email"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="gender"
                    label="Gender"
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="gender"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="age"
                    label="Age"
                    variant="outlined"
                    margin="normal"
                    disabled
                  />
                  <ErrorMessage
                    name="age"
                    component="div"
                    className="error"
                  />
                  <Field
                    as={TextField}
                    fullWidth
                    name="education"
                    label="Education."
                    variant="outlined"
                    margin="normal"
                  />
                  <ErrorMessage
                    name="education"
                    component="div"
                    className="error"
                  />
                  <Box mt={2}>
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      size="large"
                    >
                      Save
                    </Button>
                    <Button
                      component={Link}
                      to="/"
                      variant="contained"
                      color="secondary"
                      size="large"
                      style={{ marginLeft: "8px" }}
                    >
                      Back
                    </Button>
                  </Box>
                </CardContent>
              </StyledCard>
            </Grid>
          </Grid>
        </Form>
      </Formik>
    </Container>
  );
};

export default EmpEdit;
