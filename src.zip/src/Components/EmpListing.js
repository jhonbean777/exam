
import React, { useEffect, useState } from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";

import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Typography,
  Paper,
  Box,
  IconButton,
  Card,
  Container,
  CardContent,
  styled,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import VisibilityIcon from "@mui/icons-material/Visibility";
import AddIcon from "@mui/icons-material/Add"; // Import AddIcon

const StyledTable = styled(Table)(({ theme }) => ({
  width: "90%",
  margin: "50px 0 0 50px",
}));

const THead = styled(TableRow)(({ theme }) => ({
  "& > th": {
    fontSize: "16px",
    background: "#000000",
    color: "#FFFFFF",
  },
}));

const TRow = styled(TableRow)(({ theme }) => ({
  "& > td": {
    fontSize: "18px",
  },
}));

const CardWrapper = styled(Card)(({ theme }) => ({
  margin: theme.spacing(2, 0),
}));

const EmpListing = () => {
  const [empdata, empdatachange] = useState(null);
  const navigate = useNavigate();

  const LoadDetail = (id) => {
    navigate("/employee/detail/" + id);
  };

  const LoadEdit = (id) => {
    navigate("/employee/edit/" + id);
  };

  const Removefunction = (id) => {
    if (window.confirm("Do you want to remove?")) {
      fetch("http://localhost:8000/employee/" + id, {
        method: "DELETE",
      })
        .then((res) => {
          alert("Removed successfully.");
          window.location.reload();
        })
        .catch((err) => {
          console.log(err.message);
        });
    }
  };

  useEffect(() => {
    fetch("http://localhost:8000/employee")
      .then((res) => res.json())
      .then((resp) => {
        empdatachange(resp);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, []);

  return (
    <Container className="page-wrapper">
      <Container className="wrapper">
        <CardContent>
          <Typography variant="h4" style={{ marginBottom: "16px", marginTop: "90px", textAlign: "center" }}>
            Employee Listing
          </Typography>
          <Button
            variant="contained"
            color="primary"
            component={RouterLink}
            to="/employee/create"
            startIcon={<AddIcon />}
          >
            Add New
          </Button>
        </CardContent>


        <StyledTable>
          <TableHead>
            <THead>
              <TableCell>Id</TableCell>
              <TableCell>First Name</TableCell>
              <TableCell>Last Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>Age</TableCell>
              <TableCell>Education</TableCell>
            </THead>
          </TableHead>
          <TableBody>
            {empdata &&
              empdata.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>{item.id}</TableCell>
                  <TableCell>{item.firstName}</TableCell>
                  <TableCell>{item.lastName}</TableCell>
                  <TableCell>{item.email}</TableCell>
                  <TableCell>{item.gender}</TableCell>
                  <TableCell>{item.age}</TableCell>
                  <TableCell>{item.education}</TableCell>
                  <TableCell>
                    <IconButton
                      onClick={() => LoadEdit(item.id)}
                      color="primary"
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      onClick={() => Removefunction(item.id)}
                      color="secondary"
                    >
                      <DeleteIcon />
                    </IconButton>
                    <IconButton
                      onClick={() => LoadDetail(item.id)}
                      color="primary"
                    >
                      <VisibilityIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </StyledTable>
      </Container>
    </Container>

  );
};

export default EmpListing;
