// import React from 'react';
// import { AppBar, Toolbar, Typography, Container,makeStyles } from '@mui/material';

// const Footer = () => {
//   return (
//     <div className='footer-section'>
//       <AppBar position="fixed" color="primary" style={{ top: 'auto', bottom: 0}}>
//         <Container>
//           <Toolbar>
//             <Typography variant="body1" color="inherit">
//               &copy; {new Date().getFullYear()}. All rights reserved.xdbjsdbksjfhdkjfhnkdsj
//             </Typography>
//           </Toolbar>
//         </Container>
//       </AppBar>
//     </div>
//   );
// };

// export default Footer;

import React from 'react';
import { AppBar, Toolbar, Typography, Container } from '@mui/material';

const Footer = () => {
  return (
    <div className='footer-section'>
      <AppBar position="fixed" className='footer-appbar' style={{ top: 'auto', bottom: 0}}>
        <Container>
          <Toolbar>
            <Typography variant="body1" color="inherit">
              <p> &copy; {new Date().getFullYear()} Your App Name. All rights reserved.</p>
            </Typography>
          </Toolbar>
        </Container>
      </AppBar>
    </div>
  );
};

export default Footer;
