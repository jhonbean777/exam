// import React from 'react';
// import { AppBar, Toolbar, Typography, Container } from '@mui/material';

// const Header = () => {
//   return (

//       <AppBar position="fixed" style={{ bottom: 'auto', top: 0 }}>
//         <Toolbar>
          
//           <Typography variant="h6">
//             Emplyee Management System
//           </Typography>
//         </Toolbar>
//       </AppBar>




//   );
// };

// export default Header;
import React from 'react';
import { AppBar, Toolbar, Typography } from '@mui/material';
import Logo from '../assets/Images/aress-logo.png'; // Import your logo image
// import './Header.css'; // Import your CSS file

const Header = () => {
  return (
    <AppBar position="fixed" className="header"> {/* Apply the "header" class */}
      <Toolbar>
        <img src={Logo} alt="Logo" className="logo" /> {/* Apply the "logo" class */}
        <Typography variant="h6">
          Employee Management System
        </Typography>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
